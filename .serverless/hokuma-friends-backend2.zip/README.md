## ホクマフレンズ

https://i948gk4k0m.execute-api.ap-northeast-1.amazonaws.com/dev/api/gacha/platinum/
